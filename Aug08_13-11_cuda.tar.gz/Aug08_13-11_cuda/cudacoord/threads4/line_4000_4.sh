#!/bin/bash
#SBATCH -A CNHPC_1450168
#SBATCH -p boost_usr_prod
#SBATCH --qos boost_qos_dbg   # boost_qos_dbg
#SBATCH --time 00:15:00       # format: HH:MM:SS
#SBATCH -N 1                  # 1 node
#SBATCH --ntasks-per-node=1   # 4 tasks out of 32
#SBATCH --cpus-per-task=4
#SBATCH --gres=gpu:1          # 1 gpus per node out of 4
#SBATCH --mem=64000          # memory per node out of 494000MB
#SBATCH --job-name=plmdbench_line_4000_4
#SBATCH -o %x.%j.out
#SBATCH -e %x.%j.err.out

export MODULEPATH=/leonardo/pub/userexternal/drapetti/plumed_cuda/modules/:$MODULEPATH

module load gcc/12.2.0
module load openmpi/4.1.6--gcc--12.2.0-cuda-12.2
#in /leonardo/pub/userexternal/drapetti/plumed_cuda/modules the plumed installed is called "myplumed" to not conflict with the official leonardo version
module load myplumed/v2.10


module load cuda/12.2

export PLUMED_NUM_THREADS=4
export PLUMED_MAXBACKUP=0



#export NVCOMPILER_ACC_NOTIFY=31

plumed --no-mpi  benchmark --plumed="plumedCuda4000.dat:plumedCudaFloat4000.dat" \
    --kernel="this" \
    --maxtime=840 \
    --natoms=4000 \
    --nsteps=500 \
    --atom-distribution=line \
    >"line_4000_4.out"
